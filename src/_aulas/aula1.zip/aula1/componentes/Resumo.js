function Resumo(props) {
  return (
    <>
      <p>Resumo</p>
      <p>{props.children}</p>
    </>
  );
}

export { Resumo };
