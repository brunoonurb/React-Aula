function Nome() {
  return (
    <>
      <p>Bruno Pedroso</p>
    </>
  );
}

export { Nome };
