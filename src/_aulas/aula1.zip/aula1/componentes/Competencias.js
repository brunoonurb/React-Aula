function Competencias(props) {
  return (
    <>
      <p>{props.nome}</p>
      <p>{props.descricao}</p>
    </>
  );
}

export { Competencias };
