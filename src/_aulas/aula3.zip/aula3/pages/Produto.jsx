import ListaProdutos from "../componentes/ListaProdutos";

function Produto() {
  return (
    <>
      <ListaProdutos />
    </>
  );
}

export { Produto };
