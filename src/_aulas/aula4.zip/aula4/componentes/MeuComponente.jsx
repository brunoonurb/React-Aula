function MeuComponente() {
  return (
    <div>
      <h2>MeuComponente</h2>
    </div>
  )
}

export default MeuComponente;
