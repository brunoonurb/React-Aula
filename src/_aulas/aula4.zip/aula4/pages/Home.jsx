import NavBar from "../componentes/NavBar";

function Home() {
  return (
    <div>
      <NavBar/>
      <h2>Home</h2>
    </div>
  );
}

export { Home };
